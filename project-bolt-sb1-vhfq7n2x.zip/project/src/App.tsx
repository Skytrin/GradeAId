import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link, useLocation } from 'react-router-dom';
import { GraduationCap, BarChart2, Users, Mail, Package } from 'lucide-react';

import Home from './pages/Home';
import Analytics from './pages/Analytics';
import About from './pages/About';
import Contact from './pages/Contact';
import Product from './pages/Product';

function NavLink({ to, children, icon: Icon }: { to: string; children: React.ReactNode; icon: React.ElementType }) {
  const location = useLocation();
  const isActive = location.pathname === to;
  
  return (
    <Link
      to={to}
      className={`flex items-center px-4 py-2 rounded-lg transition-colors ${
        isActive
          ? 'bg-indigo-100 text-indigo-700'
          : 'text-gray-600 hover:bg-indigo-50 hover:text-indigo-600'
      }`}
    >
      <Icon className="w-5 h-5 mr-2" />
      {children}
    </Link>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen bg-gray-50">
        <nav className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex justify-between h-16">
              <div className="flex items-center">
                <GraduationCap className="w-8 h-8 text-indigo-600" />
                <span className="ml-2 text-xl font-semibold text-gray-900">GradeAid</span>
              </div>
              <div className="flex items-center space-x-4">
                <NavLink to="/" icon={GraduationCap}>Home</NavLink>
                <NavLink to="/product" icon={Package}>Product</NavLink>
                <NavLink to="/analytics" icon={BarChart2}>Material and Analytics</NavLink>
                <NavLink to="/about" icon={Users}>About Us</NavLink>
                <NavLink to="/contact" icon={Mail}>Contact</NavLink>
              </div>
            </div>
          </div>
        </nav>

        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/product" element={<Product />} />
            <Route path="/analytics" element={<Analytics />} />
            <Route path="/about" element={<About />} />
            <Route path="/contact" element={<Contact />} />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default App;