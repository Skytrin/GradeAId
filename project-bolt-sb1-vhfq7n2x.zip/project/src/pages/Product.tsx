import React from 'react';
import { 
  CheckCircle2, 
  Scale, 
  Database,
  Search,
  Clock,
  Settings,
  Files
} from 'lucide-react';

function FeatureCard({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) {
  return (
    <div className="bg-white p-8 rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 border border-gray-100">
      <div className="bg-gradient-to-br from-indigo-50 to-blue-50 w-12 h-12 rounded-xl flex items-center justify-center mb-6">
        <Icon className="w-6 h-6 text-indigo-600" />
      </div>
      <h3 className="text-xl font-semibold text-gray-900 mb-3">{title}</h3>
      <p className="text-gray-600 leading-relaxed">{description}</p>
    </div>
  );
}

function Product() {
  return (
    <div className="space-y-16">
      <div className="text-center max-w-3xl mx-auto">
        <h1 className="text-4xl font-bold mb-6">
          <span className="text-[#FF9966]">Grade</span>
          <span className="text-[#66BB6A]">Aid</span>
          <span className="relative">
            <span className="absolute -top-6 right-[-20px] text-red-600 font-handwriting transform rotate-12 text-3xl">A+</span>
          </span>
        </h1>
        <p className="text-xl text-gray-600 leading-relaxed">
          Transform your grading workflow with powerful, intelligent features
        </p>
      </div>

      <section className="relative">
        <div className="absolute inset-0 bg-gradient-to-b from-gray-50 to-white -z-10 rounded-3xl"></div>
        <div className="max-w-7xl mx-auto px-4 py-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-12 text-center">Features of Service</h2>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <FeatureCard
              icon={CheckCircle2}
              title="Specific Prompt Grading"
              description="Grade assignments based on specifically desired prompts and criteria, ensuring precise evaluation for your unique requirements."
            />
            
            <FeatureCard
              icon={Scale}
              title="Smart Grade Recommendations"
              description="Receive intelligent grade recommendations based on your defined rubric and grading scale, maintaining consistency across all evaluations."
            />
            
            <FeatureCard
              icon={Database}
              title="Local & Secure"
              description="All processing happens locally on your device, ensuring complete data security and privacy of your academic materials."
            />
            
            <FeatureCard
              icon={Search}
              title="Reliable Source Control"
              description="Uses only your provided materials for grading, avoiding unreliable internet sources and maintaining academic integrity."
            />
            
            <FeatureCard
              icon={Clock}
              title="Rapid Processing"
              description="Quickly scan and process large bodies of text without lengthy buffering times, saving valuable research hours."
            />
            
            <FeatureCard
              icon={Settings}
              title="Adjustable Grading System"
              description="Customize rubrics and grading scales to match your specific requirements and academic standards."
            />
            
            <FeatureCard
              icon={Files}
              title="Broad Format Support"
              description="Seamlessly work with multiple file formats including PDF, Excel, Word, JPEG, and TXT files for maximum flexibility."
            />
          </div>
        </div>
      </section>
    </div>
  );
}

export default Product;